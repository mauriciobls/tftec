﻿namespace ShopTFTEC.Admin.Models
{
    public class ConfigurationImagens
    {
        public string NomePastaImagensProdutos { get; set; }
        public string RepositorioBlob { get; set; }
    }
}
