﻿namespace ShopTFTEC.Admin.Models;

public class oidc
{
    public string loginUrl { get; set; }    
    public string logoutUrl { get; set; }
}
