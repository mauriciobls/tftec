﻿namespace ShopTFTEC.Admin.Services;

public interface ISeedUserClaimsInitial
{
    Task SeedUserClaims();
}
